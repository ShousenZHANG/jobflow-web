import './assets/service-worker.ts-BR-SLY3P.js';
